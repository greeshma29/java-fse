package com.cts.training.spring.services;

public interface IMessageService {
	public String sendMessage(String to, String message);
}
