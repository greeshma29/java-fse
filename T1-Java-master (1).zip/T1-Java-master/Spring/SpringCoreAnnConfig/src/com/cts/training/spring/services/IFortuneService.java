package com.cts.training.spring.services;

public interface IFortuneService {
	
	public String dailyFortune();

}
