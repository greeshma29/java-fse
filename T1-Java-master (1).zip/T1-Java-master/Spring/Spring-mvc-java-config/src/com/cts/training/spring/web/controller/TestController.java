package com.cts.training.spring.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TestController {

	/*@RequestMapping("/index")
	public String test() {
		return "home-page";
	}*/
}
