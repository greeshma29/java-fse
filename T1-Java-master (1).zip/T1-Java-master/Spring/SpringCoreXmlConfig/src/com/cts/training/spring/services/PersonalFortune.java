package com.cts.training.spring.services;

public class PersonalFortune implements IFortuneService {

	@Override
	public String dailyFortune() {
		// TODO Auto-generated method stub
		return "Today is your lucky day!!!";
	}

}
