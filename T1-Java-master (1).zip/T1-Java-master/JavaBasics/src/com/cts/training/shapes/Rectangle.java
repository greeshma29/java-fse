package com.cts.training.shapes;

public class Rectangle extends Shape{

	int length,breadth;
	
	
	@Override
	public void calcArea() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void calcPerimeter() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("Rectangle Drawn");
	}

}
