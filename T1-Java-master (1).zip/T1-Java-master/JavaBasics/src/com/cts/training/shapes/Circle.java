package com.cts.training.shapes;

public class Circle extends Shape{

	int radius;
	final double PI = 3.14;
	
	@Override
	public void calcArea() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void calcPerimeter() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("Circle Drawn");
	}

}
