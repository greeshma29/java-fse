package com.cts.training.shapes;

public class Square extends Shape {

	int side;
	@Override
	public void calcArea() {
		// TODO Auto-generated method stub

	}

	@Override
	public void calcPerimeter() {
		// TODO Auto-generated method stub

	}

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("Square Drawn");
	}

}
