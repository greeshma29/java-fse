package com.cts.training.general;

public class Sample {
	private int a, b;
	public int c;
	
	public Sample() {
		// TODO Auto-generated constructor stub
		this.a = 10;
		this.b = 20;
		this.c = 30;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "My Message";
	}
	
}
