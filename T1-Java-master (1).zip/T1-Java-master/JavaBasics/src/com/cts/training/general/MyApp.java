package com.cts.training.general;

public class MyApp {
	public static void main(String args[]) {
		Sample S1 = new Sample();
		System.out.println(S1);
		
		String str = "Hello" + S1; // S1.toString();
		System.out.println(str);
	}
}



























