package com.cts.training.excp;

// public class InvalidAgeException extends RuntimeException{
public class InvalidAgeException extends Exception{

	public InvalidAgeException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
