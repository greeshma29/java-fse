package com.cts.training.interfaceex;

public class MyApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MethodCheckImpl obj = new MethodCheckImpl();
		obj.fun();
	}

}
