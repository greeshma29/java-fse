package com.cts.training.interfaceex;

public class MethodCheckImpl implements IMethodCheck{
	@Override
	public void fun() {
		// TODO Auto-generated method stub
		System.out.println("Fun of MethodCheckImpl");
	}
}
