package com.cts.training.lambdas;



@FunctionalInterface
public interface Greetings {
	
	void sendGreeting(String message);
}
